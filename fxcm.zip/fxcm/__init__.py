from fxcm.fxcm import fxcm as fxcm  
from fxcm.fxcm_open_position import fxcm_open_position 
from .fxcm_closed_position import *
from .fxcm_order import *
from .fxcm_oco_order import *

